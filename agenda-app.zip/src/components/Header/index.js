import React from 'react';
import './style.css';

function Header() {
    return (
        <header id="nav">
            CRUD com Exclusão fisica/logica em REACTJS e NODEJS com MongoDB
        </header>
    );
}

export default Header;