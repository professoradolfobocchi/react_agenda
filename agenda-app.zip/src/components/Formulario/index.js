import React, { useState } from 'react';
import './style.css';

function Formulario(props) {
    const[dados, setDados] = useState({
        nome: '', email: '', telefone: '', profissao: ''
    });

    function handleChange(e) {
        setDados({...dados, [e.target.id]: e.target.value});
    }
    function handleSubmit(e) {
        e.preventDefault();       
        props.setListaContatos([...props.listaContatos, dados]);
        setDados({
            nome: '', email: '', telefone: '', profissao: ''
        });
    }

    return (
        <form onSubmit={handleSubmit}>
            <div id="entradaDeDados">
                <input id="nome" onChange={handleChange} value={dados.nome} className="input-text" placeholder="Nome" type="text" required />
                <input id="email" onChange={handleChange} value={dados.email} className="input-text" placeholder="Email" type="email" required />
                <input id="telefone" onChange={handleChange} value={dados.telefone} className="input-text" placeholder="Telefone" type="text" required />
                <input id="profissao" onChange={handleChange} value={dados.profissao} className="input-text" placeholder="Profissão" type="text" required />
                <input className="input-btn" type="submit" value="Enviar"  />
            </div>
        </form>
    );
}

export default Formulario;