const contatos = [
    {
        id: 1, 
        nome: 'Adolfo Bocchi', 
        email: 'adolfo.bocchi@sp.senac.br', 
        telefone: '(18) 99876-5432',
        profissao: 'Docente'
    }
];

export default contatos;